clc; clear; close all; warning off;

DATA_DIR='/mnt/HDD01/rspl-admin /ASL vs Daily Videos/RD OF and PSD/New ASL/';
% OUT_DIR = 'C:\Users\mrahman17\Desktop\77 GHz\output_77_20\Exp4\sub1_rangeOF_vs_velOF\';
pattern = strcat(DATA_DIR, '*.mat');    % file pattern
files = dir(pattern);

I_MAX = numel(files); % # of files in "files" 
daily_data_dir= '/mnt/HDD01/rspl-admin /ASL vs Daily Videos/RD OF and PSD/New Daily 20 sec/';
% daily_out = 'C:\Users\mrahman17\Desktop\77 GHz\Daily_Data_Output\new_data\Optical Flows\';
pattern1 = strcat(daily_data_dir, '*.mat');    % file pattern
files1 = dir(pattern1); 
J_MAX=numel(files1);
ASL_betabar = zeros(1,I_MAX);
ASL_beta_mean = zeros(1,I_MAX);
dailybetabar = zeros(1,J_MAX);
daily_beta_mean = zeros(1,J_MAX);
magnitude_func_ASL = cell(1,I_MAX);
magnitude_func_daily = cell(1,J_MAX);
% w = waitbar(0);
fps = 25;
weights = [0.9999999 0.99999999 0.999999999 0.9999999999]; 

for m=1:length(weights)
        weight = weights(m);
        for j=1:J_MAX
                msg = strcat(['Processing file ', int2str(j), ' of ', int2str(J_MAX+I_MAX)]);   % loading message
                %     waitbar(j/J_MAX, w, msg);
                disp(msg);
                
                fName1 = files1(j).name;
                [foo1, name, foo2] = fileparts(fName1);
                fIn1 = strcat(daily_data_dir, fName1);
                %     [~,~,~,~,Daily_betabar(j)] = Fractal_func_v2(fIn1,fName1);
                [dailybetabar(j), daily_beta_mean(j), magnitude_func_daily{1,j}] = Frac_from_PSD_Weighted(fIn1,fps,weight);
                
        end
        for i = 1:I_MAX
                msg = strcat(['Processing file ', int2str(j+i), ' of ', int2str(I_MAX+J_MAX)]);   % loading message
                %     waitbar(i/I_MAX, w, msg);
                disp(msg);
                
                fName = files(i).name;
                [foo1, name, foo2] = fileparts(fName);
                fIn = strcat(DATA_DIR, fName);
                % [~,~,~,~,ASL_betabar(i)] = Fractal_func_v2(fIn,fName);
                [ASL_betabar(i), ASL_beta_mean(i),magnitude_func_ASL{1,i}] = Frac_from_PSD_Weighted(fIn,fps,weight);
                
        end
        savepath = strcat('/mnt/HDD01/rspl-admin /ASL vs Daily Videos/Fractal Complexity Results/New RD Map Results/New RD_Video_ASLvsDaily_',num2str(100*weight,'%11.9f'),'percent.mat');
        save(savepath, 'ASL_betabar','ASL_beta_mean','dailybetabar','daily_beta_mean','magnitude_func_ASL','magnitude_func_daily');
    
end