clear; clc; warning off; close all;

video_dir = 'C:\Users\mrahman17\Desktop\77 GHz\Dr Malaia Fractal Comp\Orig.Videos\';
video_name = 'e51_F_cut.avi';
fNameOut = 'C:\Users\mrahman17\Desktop\Fractal Complexity\20secs\';
activity = 'Unboxing Nintendo';
video = strcat (video_dir, video_name); 
% v = VideoReader(fNameIn);
v = VideoReader(video);

opticFlow = opticalFlowLK('NoiseThreshold',0.009); % 'NoiseThreshold',0.009
i = 1;
abs_mag = zeros(v.Width*v.Height,100); % 332x384 for 77 GHz
while hasFrame(v)
    frameRGB = readFrame(v);
    frameGray = rgb2gray(frameRGB);
    flow = estimateFlow(opticFlow,frameGray);
        x_vel(:,:,i) = flow.Vx; % X direction is top to bottom and Y direction is left to right 
        y_vel(:,:,i) = flow.Vy;
        magnitudes(:,:,i) = flow.Magnitude;
        orientations(:,:,i) = flow.Orientation;
        abs_mag(:,i) = reshape(abs(magnitudes(:,:,i)),1,v.Width*v.Height);
        abs_x_vel(:,i) = reshape(abs(x_vel(:,:,i)),1,v.Width*v.Height);
        abs_y_vel(:,i) = reshape(abs(y_vel(:,:,i)),1,v.Width*v.Height);
    i = i + 1;
%     figure(1)
%      imshow(frameRGB)
%      figure(2)
%      imshow(frameGray)
     
end
n_frames = i;

%% Optical Flow for Range

bin_size = 0.005;
num_bins = round(max(abs_y_vel(:))/bin_size+1); %
max_abs_y = max(abs_y_vel(:));
bin_axis = linspace(0, max_abs_y, num_bins);
bin_axis2 = fliplr(bin_axis);

[r, c] = size(abs_y_vel);
hist_mag = zeros(num_bins,c);
timeaxis = linspace(0, v.Duration, 100);
for f = 1:c
    for i = 1:r
        %a = num_bins-round(abs_y_vel(i,f)/bin_size);
        a = round(abs_y_vel(i,f)/bin_size)+1;
        hist_mag(a,f) = hist_mag(a,f) + 1;
    end
end
hist_mag_flip = flipud(hist_mag);
hist_mag_thresh = hist_mag_flip;
hist_mag_thresh(hist_mag_thresh<5)=0;
%% Optical Flow Diagram
% fig = figure(1);
% colormap(jet(256));
% imagesc(timeaxis,[] ,20*log10(hist_mag_thresh));
% % yticklabels(bin_axis2(1), bin_axis2(553), bin_axis2(end));
% set(gca,'YtickLabel',max_abs_y:-1:0)
% title({'Optical Flow Diagram of: ',activity});
% xlabel('Time (sec)');
% ylabel('Optical Flow (px/frame)');
% caxis([0 30])

%% PSD
hist_mag = hist_mag(:,1:500);
freqaxis = linspace(0, v.FrameRate/2); % 25 FPS
[m, n] = size(hist_mag);
window = n; noverlap = 5*window/6; nfft = 2500;

for i =1:size(hist_mag,1)
    psd(:,i) = pwelch(hist_mag(i,:)', window, noverlap, nfft); % 257x1074

end
psdout = psd'; % 1074x257

hist_pdf = hist_mag/(size(hist_mag,1)*bin_size);

% fig = figure;
% colormap(jet(256));
% %imagesc(freqaxis, bin_axis,20*log10(psd')/max(max(psd)));
% imagesc(freqaxis, bin_axis, 20*log10(psdout(350:end,:)));
% set(gca,'YtickLabel',max(abs_mag(:)):-1:0)
% title({'Power Spectral Density of ', video_name(1:end-4)});
% xlabel('Frequency (Hz)');
% ylabel('Optical Flow (px/frame)');
% %ytickformat('%.2f')
% caxis([-150 100])
% %set(gca, 'Visible', 'off')
 


% savename = strcat(fNameOut(1:(end-4)),'_PSD.png');
%savename = strcat(save_dir,video_name(1:end-4),'_PSD.png');
%saveas(fig,savename);

%% linear log/log
% ln(M) = beta*ln(f)+alpha          y = a*x+b
size_j = size(psdout,1);
size_f = size(psdout,2);

fits = cell(1,size_j); % 1x1074 cell
% for j = 1:size_j
%     if psdout(j,1) > 0
%         freq = log((2:size_f-1)/(size_f-1)*v.FrameRate/2);
%         magnitude = log(psdout(j,2:size_f-1));
%         fits{j} = fit(freq',magnitude','poly1');
%     end
% end
for f = 1:size_f
    if psdout(1,f) > 0
        freq = psdout(:,f);
        magnitude = log(psdout(:,2:size_f-1));
        fits{j} = fit(freq',magnitude','poly1');
    end
end
psdVector = sum(psdout,1);
freqVec = log((2:size_f-1)/(size_f-1)*v.FrameRate/2);
fitVec = fit(freq',log(psdVector(2:size_f-1))','poly1');
fitVecDaily = fitVec.p1;
% plot(exp(fits{size_j}.p2)./abs(exp(freq)).^(-fits{size_j}.p1))
% hold on
% plot(psdout(size(psdout,1),2:size_f))
betabar = 0;
k=0;
for i=1:size_j
    if ~isempty(fits{i})
        betabar = betabar + fits{i}.p1;
        k = k+1;
    end
end
betabar = - betabar;
betabarmean = betabar/k; % mean fractal complexity


alphabar = 0;
j=0;
for i=1:size_j
    if ~isempty(fits{i})
        alphabar = alphabar + exp(fits{i}.p2);
        j = j+1;
    end
end
alphabarmean = alphabar/j; % mean spectral density amplitude

%% Mean of Magnitude func

count = 0;
for i = 1:size_j
    if ~isempty(fits{i})
    magnitude_func(i,:) = exp(fits{i}.p2)./abs(exp(freq)).^(-fits{i}.p1);
    count = count+1;
    end
    
end
magnitude_mean = mean(magnitude_func);

%% Plot PSD and its mean
% figure;
% plot(20*log(psdout(:,1:size_f)'),'m');
% hold on
% meanpsd = mean(psdout);
% plot(20*log(meanpsd(:,1:size_f))','r');
% plot(20*log(magnitude_mean),'y');

%% Compare ASL vs Daily
[psdout2, size_f2, magnitude_mean2, video_name2, betabar2, fitVec2] = Fractal_Comp_Func(); % retrieve ASL data
% 
% figure;
% hold on
% plot(20*log(psdout2(:,1:size_f2)'),'c'); % ASL psd
% plot(20*log(psdout(:,1:size_f)'),'m'); % daily psd
% meanpsd = mean(psdout);
% meanpsd2 = mean(psdout2);
% plot(20*log(meanpsd(:,1:size_f))','r'); % daily mean
% plot(20*log(meanpsd2(:,1:size_f2))','b'); % ASL mean
% plot(20*log(magnitude_mean),'y'); % daily magnitude func
% plot(20*log(magnitude_mean2),'k'); % ASL magnitude func

%% Normalized ASL vs Daily
% Adjust axises
freqaxis = linspace(1, v.FrameRate/2, size_f);
logaxis = 20*log(linspace(1, v.FrameRate/2, size_f));
logaxis2 = round(logaxis,1);
titname = str2double(strcat(video_name2(3),video_name2(4)));
titname2 = int2str(titname-63);
str = sprintf('Experiment 4 activity #%s vs Daily(%s)', titname2, activity);

fig1 = figure();
hold on
title(str, 'FontSize', 18);
xlabel('Log_{2} (Hz)','FontSize', 18);
ylabel('Normalized PSD (dB)','FontSize', 18);
xticks(0:50:size_f) % 1250/50 = 25 which is our FPS
xticklabels(logaxis2)
ax = get(gca,'XTickLabel');
set(gca,'XTickLabel',ax,'FontName','Times','fontsize',18)
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'Position',  [10, 10, 1600, 1000])

% p1 = plot(20*log(psdout2(:,101:size_f2-2)'./max(magnitude_mean2(:,101:end))),'c'); % ASL psd
% p2 = plot(20*log(psdout(:,101:size_f-2)'./max(magnitude_mean2(:,101:end))),'m'); % daily psd
p1 = plot(log(psdout2(:,101:size_f2-2)'),'c'); % ASL psd
p2 = plot(log(psdout(:,101:size_f2-2)'),'m'); % daily psd


meanpsd = mean(psdout);
meanpsd2 = mean(psdout2);
p3 = plot(log(meanpsd(:,101:size_f-2)'./max(magnitude_mean2(:,101:end))),'r', 'LineWidth', 3); % daily mean
p4 = plot(log(meanpsd2(:,101:size_f2-2)'./max(magnitude_mean2(:,101:end))),'b', 'LineWidth', 3); % ASL mean
p5 = plot(log(magnitude_mean(:,101:end)./max(magnitude_mean2(:,101:end))),'--y', 'LineWidth', 4); % daily magnitude func
p6 = plot(log(magnitude_mean2(:,101:end)./max(magnitude_mean2(:,101:end))),'--k', 'LineWidth', 4); % ASL magnitude func
% p6 = plot(20*log(magnitude_mean2(:,101:end)./max(magnitude_mean2(:))),'--k', 'LineWidth', 4); % ASL magnitude func
legend([p1(1) p2(1) p3 p4 p5 p6],{'ASL PSD','Daily PSD','Daily mean','ASL mean','Daily fit','ASL fit'})

savename = strcat(fNameOut,activity,'Betabar_',int2str(betabar),' vs ',int2str(titname),'Betabar2_',int2str(betabar2),'.png');
savename2 = strcat(savename(1:end-4),'.fig');
saveas(fig1,savename);
saveas(fig1,savename2);
