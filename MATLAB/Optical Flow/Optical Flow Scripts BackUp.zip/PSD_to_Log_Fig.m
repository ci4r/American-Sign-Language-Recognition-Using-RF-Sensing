clc; clear; close all
%% Load PSD files
dailypath = '/mnt/HDD01/rspl-admin /ASL vs Daily Videos/Video OF and PSD/Daily 20 sec/';
ASLpath = '/mnt/HDD01/rspl-admin /ASL vs Daily Videos/Video OF and PSD/ASL/';

dailyfile = '02090010_1579561292_PSD_1.mat';
aslfile = '02700024_PSD.mat';

daily = fullfile(dailypath, dailyfile);
asl = fullfile(ASLpath, aslfile);
load(daily);

if exist('psdout1','var') == 1
        psddaily = psdout1;
        clear psdout1
end
if exist('psdout2','var') == 1
        psddaily = psdout2;
        clear psdout2
end
if exist('psdout3','var') == 1
        psddaily = psdout3;
        clear psdout3
end
if exist('psdout','var') == 1
        psddaily = psdout;
        clear psdout
end

load(asl);

psdasl = psdout; clear psdout;

fps = 30;
freqaxisASL = linspace(0.01, fps/2, size(psdasl,2));
freqaxisdaily = linspace(0.01, fps/2, size(psddaily,2));

logaxisASL = linspace(0,log2(fps/2),size(psdasl,2));
logaxisdaily = linspace(0,log2(fps/2),size(psddaily,2));
%% Fractal Complexity

start_bin_asl = 150;
start_bin_daily = 150;

ending_bin = 201;%size(psddaily,1);

% [betaasl, betameanasl, magnitude_asl] = Frac_Comp_from_PSD(asl,fps,start_bin_asl,ending_bin);
% 
% [betadaily, betameandaily, magnitude_daily] = Frac_Comp_from_PSD(daily,fps, start_bin_daily,ending_bin);

weights = [0.9999999 0.99999999 0.999999999 0.9999999999]; 

[betaasl, betameanasl, magnitude_asl, start_bin_asl] = Frac_from_PSD_Weighted(asl,fps,weights(4));
[betadaily, betameandaily, magnitude_daily, start_bin_daily] = Frac_from_PSD_Weighted(daily,fps, weights(4));


%% Plot Figure

one_hz_daily = floor(length(freqaxisdaily)/15);
one_hz_asl = floor(length(freqaxisASL)/15);

fig = figure();
hold on
%ylim([-4 4])
xlim([1 4])

meanpsd = mean(psddaily(start_bin_daily:ending_bin,one_hz_daily:end));
meanpsd2 = mean(psdasl(start_bin_asl:ending_bin,one_hz_asl:end));

p1 = plot(logaxisASL(one_hz_asl:end), log2(psdasl(start_bin_asl:ending_bin,one_hz_asl:end)./max(magnitude_asl(one_hz_asl:end))),'-c','LineWidth', 2); % ASL psd
p2 = plot(logaxisdaily(one_hz_daily:end), log2(psddaily(start_bin_daily:ending_bin,one_hz_daily:end)./max(magnitude_daily(one_hz_daily:end))),'-m','LineWidth', 2); % daily psd

p3 = plot(logaxisdaily(one_hz_daily:end),log2(meanpsd./max(magnitude_daily(one_hz_daily:end))),'r', 'LineWidth', 3); % daily mean
p4 = plot(logaxisASL(one_hz_asl:end), log2(meanpsd2./max(magnitude_asl(one_hz_asl:end))),'b', 'LineWidth', 3); % ASL mean
p5 = plot(logaxisdaily(one_hz_daily+1:end-1), log2(magnitude_daily(one_hz_daily:end)./max(magnitude_daily(one_hz_daily:end))),'--y', 'LineWidth', 5); % daily magnitude func
p6 = plot(logaxisASL(one_hz_asl+1:end-1),log2(magnitude_asl(one_hz_asl:end)./max(magnitude_asl(one_hz_asl:end))),'--k', 'LineWidth', 5); % ASL magnitude func
legend([p1(1) p2(1) p3 p4 p5 p6],{'ASL PSD','Daily PSD','Daily mean','ASL mean','Daily fit','ASL fit'})

titname = str2double(aslfile(3:4));
titname2 = int2str(titname-63);
str = sprintf('Experiment 4 activity #%s (Betabar: %f, Betabarmean: %f) vs \n Daily ''%s'' (Betabar: %f, Betabarmean: %f) \n ASL Bins: %d - %d \t Daily Bins: %d - %d', ...
        titname2, betaasl, betameanasl, dailyfile(3:4), betadaily, betameandaily, start_bin_asl, ending_bin, start_bin_daily, ending_bin);

title(str, 'FontSize', 18,'fontweight','bold');
% xlabel('Log_{2} (Hz)','FontSize', 18);
xlabel('Log_{2} (Hz)','FontSize', 18,'fontweight','bold');
ylabel('Normalized PSD','FontSize', 18,'fontweight','bold');
% xticks(0:50:size_f) % 1250/50 = 25 which is our FPS
% xticklabels(logaxis2)
ax = get(gca,'XTickLabel');
set(gca,'XTickLabel',ax,'FontName','Times','fontsize',18)
set(gcf, 'units','normalized','Position',  [0.1, 0.2, .8, .7])

savename = strcat('/mnt/HDD01/rspl-admin /ASL vs Daily Videos/Video OF and PSD/Raw Figures/',aslfile(1:end-4),'LOG.fig');
saveas(fig,savename);
savename2 = strcat('/mnt/HDD01/rspl-admin /ASL vs Daily Videos/Video OF and PSD/Raw Figures/',aslfile(1:end-4),'LOG.png');
saveas(fig,savename2);