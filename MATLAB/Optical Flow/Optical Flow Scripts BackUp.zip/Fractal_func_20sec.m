function [psdout, size_f, magnitude_mean, video_name, fitVecASL1, fitVecASL2, fitVecASL3] = Fractal_func_20sec(fNameIn,fName)

% video_dir = 'C:\Users\mrahman17\Desktop\77 GHz\output_77_20\Exp4\sub1_video\';
% video_name = '09650022.avi';
% fNameOut = 'C:\Users\mrahman17\Desktop\77 GHz\annotation range dopp video\annotated optical flows\part 2\';
% video = strcat (video_dir, '\', video_name); 
% v = VideoReader(video);
v = VideoReader(fNameIn);
video_name = fName;


opticFlow = opticalFlowLK('NoiseThreshold',0.009); % 'NoiseThreshold',0.009
i = 1;
abs_mag = zeros(v.Width*v.Height,100); % 332x384 for 77 GHz
while hasFrame(v)
    frameRGB = readFrame(v);
    frameGray = rgb2gray(frameRGB);
    flow = estimateFlow(opticFlow,frameGray);
        x_vel(:,:,i) = flow.Vx; % X direction is top to bottom and Y direction is left to right 
        y_vel(:,:,i) = flow.Vy;
        magnitudes(:,:,i) = flow.Magnitude;
        orientations(:,:,i) = flow.Orientation;
        abs_mag(:,i) = reshape(abs(magnitudes(:,:,i)),1,v.Width*v.Height);
        abs_x_vel(:,i) = reshape(abs(x_vel(:,:,i)),1,v.Width*v.Height);
        abs_y_vel(:,i) = reshape(abs(y_vel(:,:,i)),1,v.Width*v.Height);
    i = i + 1;
     
end
n_frames = i;

%% Optical Flow for Range

bin_size = 0.005;
num_bins = round(max(abs_y_vel(:))/bin_size+1); %
bin_axis = linspace(0, max(abs_y_vel(:)), num_bins);

timeaxis = linspace(0, 20); % 9.2
[r, c] = size(abs_y_vel);
hist_mag = zeros(num_bins,c);

for f = 1:c
    for i = 1:r
        a = num_bins-round(abs_y_vel(i,f)/bin_size);
        hist_mag(a,f) = hist_mag(a,f) + 1;
    end
end

hist_mag_thresh = hist_mag;
hist_mag_thresh(hist_mag_thresh<5)=0;

%% PSD
hist_mag1 = hist_mag(:,1:500);
hist_mag2 = hist_mag(:,501:1000);
hist_mag3 = hist_mag(:,1001:1500);
freqaxis = linspace(0, 12.5); % 25 FPS
[m, n] = size(hist_mag1);
window = n; noverlap = 5*window/6; nfft = 2500;

for i =1:size(hist_mag1,1)
   psd(:,i) = pwelch(hist_mag1(i,:)', window, noverlap, nfft); % 257x107(hist_mag1,1)
   psd2(:,i) = pwelch(hist_mag2(i,:)', window, noverlap, nfft); % 257x107(hist_mag1,1)
   psd3(:,i) = pwelch(hist_mag3(i,:)', window, noverlap, nfft); % 257x107(hist_mag1,1)
end
psdout = psd'; % 1074x257
psdout2 = psd2';
psdout3 = psd3';
% hist_pdf = hist_mag/(size(hist_mag,1)*bin_size);

% fig = figure;
% colormap(jet(256));
% %imagesc(freqaxis, bin_axis,20*log10(psd')/max(max(psd)));
% imagesc(freqaxis, bin_axis, 20*log10(psdout));
% set(gca,'YtickLabel',max(abs_mag(:)):-1:0)
% title({'Power Spectral Density of ', video_name(1:end-4)});
% xlabel('Frequency (Hz)');
% ylabel('Optical Flow (px/frame)');
% caxis([-150 100])
% set(gca, 'Visible', 'off')



% savename = strcat(fNameOut(1:(end-4)),'_PSD.png');
%savename = strcat(save_dir,video_name(1:end-4),'_PSD.png');
%saveas(fig,savename);
%% Fractal Complexity


%freq = linspace(0, 12.5, size(psdout,2));

%% 1st Method linear log/log
% ln(M) = beta*ln(f)+alpha          y = a*x+b

size_j = size(psdout,1);
size_f = size(psdout,2);

% fits = cell(1,size_j); % 1x1074 cell
% fits2 = cell(1,size_j); % 1x1074 cell
% fits3 = cell(1,size_j); % 1x1074 cell
% for j = 1:size_j
%     if psdout(j,1) > 0
%         freq = log((2:size_f-1)/(size_f-1)*12.5);
%         magnitude = log(psdout(j,2:size_f-1));
%         fits{j} = fit(freq',magnitude','poly1');
%     end
%     if psdout2(j,1) > 0
%         freq = log((2:size_f-1)/(size_f-1)*12.5);
%         magnitude2 = log(psdout2(j,2:size_f-1));
%         fits2{j} = fit(freq',magnitude2','poly1');
%     end
%     if psdout3(j,1) > 0
%         freq = log((2:size_f-1)/(size_f-1)*12.5);
%         magnitude3 = log(psdout3(j,2:size_f-1));
%         fits3{j} = fit(freq',magnitude3','poly1');
%     end
% end

%% 2nd method starts
psdVector1 = sum(psdout,1); 
freqVec = log((2:size_f-1)/(size_f-1)*v.FrameRate/2); 
fitVec1 = fit(freqVec',log(psdVector1(2:size_f-1))','poly1'); 
fitVecASL1 = fitVec1.p1;

psdVector2 = sum(psdout2,1); 
fitVec2 = fit(freqVec',log(psdVector2(2:size_f-1))','poly1'); 
fitVecASL2 = fitVec2.p1;

psdVector3 = sum(psdout3,1); 
fitVec3 = fit(freqVec',log(psdVector3(2:size_f-1))','poly1'); 
fitVecASL3 = fitVec3.p1;
%% 2nd method ends

% plot(exp(fits{size_j}.p2)./abs(exp(freq)).^(-fits{size_j}.p1))
% hold on
% plot(psdout(size(psdout,1),2:size_f))

% betabar = 0;
% betabar2 = 0;
% betabar3 = 0;
% k=0;
% l=0;
% z=0;
% for i=1:size_j
%     if ~isempty(fits{i})
%         betabar = betabar + fits{i}.p1;
%         k = k+1;
%     end
%     if ~isempty(fits2{i})
%         betabar2 = betabar2 + fits2{i}.p1;
%         l = l+1;
%     end
%     if ~isempty(fits3{i})
%         betabar3 = betabar3 + fits3{i}.p1;
%         z = z+1;
%     end
% end
% betabar = - betabar;
% betabarmean = betabar/k; % mean fractal complexity
% betabar2 = - betabar2;
% betabarmean2 = betabar2/l; % mean fractal complexity
% betabar3 = - betabar3;
% betabarmean3 = betabar3/z; % mean fractal complexity
%% Alphabar


% alphabar = 0;
% alphabar2 = 0;
% alphabar3 = 0;
% j=0;
% for i=1:size_j
%     if ~isempty(fits{i})
%         alphabar = alphabar + exp(fits{i}.p2);
%         alphabar2 = alphabar2 + exp(fits2{i}.p2);
%         alphabar3 = alphabar3 + exp(fits3{i}.p2);
%         j = j+1;
%     end
% end
% alphabarmean = alphabar/j; % mean spectral density amplitude
% alphabarmean2 = alphabar2/j; % mean spectral density amplitude
% alphabarmean3 = alphabar3/j; % mean spectral density amplitude
%% Mean of Magnitude func

% count = 0;
% for i = 1:size_j
%     if ~isempty(fits{i})
%         magnitude_func(i,:) = exp(fits{i}.p2)./abs(exp(freq)).^(-fits{i}.p1);
%         magnitude_func2(i,:) = exp(fits2{i}.p2)./abs(exp(freq)).^(-fits2{i}.p1);
%         magnitude_func3(i,:) = exp(fits3{i}.p2)./abs(exp(freq)).^(-fits3{i}.p1);
%         count = count+1;
%     end
%     
% end
magnitude_mean = 0;
% magnitude_mean = mean(magnitude_func);
% magnitude_mean2 = mean(magnitude_func2);
% magnitude_mean3 = mean(magnitude_func3);
% end