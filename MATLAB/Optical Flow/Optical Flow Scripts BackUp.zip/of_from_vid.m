% properties - parameters

% subj spans 1:3;
% exp_no_ind spans 64:73;
% exp_no_ind = 64;
% subj = 2;
% exp_no = ['02' num2str(exp_no_ind) '002' num2str(subj+1)];
exp_name = 'backpacking';
% data_dir = ['G:\ASLR_May2019_Study\Kinect\Processed data\Subject' num2str(subj) '\' exp_no];
% name_lists = dir([data_dir '\sorted2\rgb']);
% numFrames_d = size(frame_ids_r,2);
frame_size = 1080*1920;
c_f_dims_d = [451,1000,826,1275];
c_f_size_d = (c_f_dims_d(2)-c_f_dims_d(1)+1)*(c_f_dims_d(4)-c_f_dims_d(3)+1);
% load([data_dir '\frame_ids_rgb_' exp_no '.mat'], 'frame_ids');
% load([data_dir '\frame_ids_' exp_no '.mat'], 'frame_ids_r');

% read files iteratively

opticFlow = opticalFlowFarneback;
% 
% h = figure;
% movegui(h);
% hViewPanel = uipanel(h,'Position',[0 0 1 1],'Title','Plot of Optical Flow Vectors');
% hPlot = axes(hViewPanel);
flows_d = cell(1,200);
% 
% outputVideo = VideoWriter(['Videos\test\' exp_no '_of.avi']);
% outputVideo.FrameRate = 30;
% open(outputVideo)

% inputVideo = VideoReader(['Videos\' exp_no '.avi']);
inputVideo = VideoReader(['Daily Data\' exp_name '.avi']);
i = 0;
while hasFrame(inputVideo)
    i = i+1;
    disp(['Reading frame: ' num2str(i) ' Daily video: ' exp_name]);
    frameRGB = readFrame(inputVideo);
%     if i > 45
    frameGray = rgb2gray(frameRGB);
%     flow = estimateFlow(opticFlow, frameGray(c_f_dims_d(1):c_f_dims_d(2),c_f_dims_d(3):c_f_dims_d(4)));
    flow = estimateFlow(opticFlow, frameGray);
    flows_d{i} = flow;
    if i == 300
        break 
    end
%     imshow(frameRGB(c_f_dims_d(1):c_f_dims_d(2),c_f_dims_d(3):c_f_dims_d(4),:))
%     imshow(frameRGB);
%     hold on
%     plot(flow_2,'DecimationFactor',[5 5],'ScaleFactor',1,'Parent',hPlot);
%     hold off
%     F = getframe(gcf);
%     writeVideo(outputVideo, F);
%     if i <= numFrames
%         frame_frz = round(frame_ids_r(2,i+1)/333333);
%     else
%         frame_frz = 1;
%     end
%     for j = frame_frz
% %         writeVideo(outputVideo,frameRGB);
%     end
    %pause(10^-3)
%     end
end

% close(outputVideo)


%% post-processing
% 
% % flow_mags = zeros(frame_size,numFrames);
% % for i = 1:numFrames
% %     flow_mags(:,i) = flows{i}.Magnitude(:);
% % end
% 
numFrames_d = size(flows_d,2);
flow_mags_c_d = zeros(c_f_size_d,numFrames_d);
temp_arr = zeros(1,c_f_size_d);
for i = 1:numFrames_d-1
    temp_arr(:) = flows_d{i}.Magnitude(c_f_dims_d(1):c_f_dims_d(2),c_f_dims_d(3):c_f_dims_d(4));
%     temp_arr(:) = flows_d{i}.Magnitude;
    flow_mags_c_d(:,i) = temp_arr;
end
% 
% % disp(['Saving 1 - subject: ' num2str(subj) ' experiment: ' exp_no])
% 
% % save([data_dir '\OF_data_2_subj' num2str(subj) '_exp_' exp_no '.mat'], 'flow_mags_c', 'flows', 'frame_ids_r', '-v7.3')
% % figure;
% % % heatmap(flow_mags);
% % 
% % hold on
% % for i = 1:339
% % scatter(i*ones(1,frame_size),flow_mags(:,i))
% % end
% % 
% % 
% 
% 
