
exp_no = ['02' num2str(exp_no_ind) '002' num2str(subj+1)];
% data_dir = ['G:\ASLR_May2019_Study\Kinect\Processed data\Subject' num2str(subj) '\' exp_no];
%load([data_dir '\OF_data_subj' num2str(subj) '_exp_' exp_no '.mat'], 'flow_mags_c', 'frame_ids');

c_f_dims = [401,950,801,1250];
c_f_size = (c_f_dims(2)-c_f_dims(1)+1)*(c_f_dims(4)-c_f_dims(3)+1);


%%
frame_ids_r(2,2:size(frame_ids_r,2)) = frame_ids_r(1,2:size(frame_ids_r,2))-frame_ids_r(1,1:size(frame_ids_r,2)-1);
flow_mags_norm_2 = zeros(c_f_size,size(flow_mags_c,2));
k = 0;
for i = 2:size(flow_mags_c,2)-1
    if frame_ids_r(2,i) < 450000
        k = k+1;
        flow_mags_norm_2(:,k) = flow_mags_c(:,i);
    elseif frame_ids_r(2,i) < 750000
        k = k+1;
        flow_mags_norm_2(:,k) = flow_mags_c(:,i)/2;
        k = k+1;
        flow_mags_norm_2(:,k) = flow_mags_c(:,i)/2;
    elseif frame_ids_r(2,i) < 1050000
        k = k+1;
        flow_mags_norm_2(:,k) = flow_mags_c(:,i)/3;
        k = k+1;
        flow_mags_norm_2(:,k) = flow_mags_c(:,i)/3;
        k = k+1;
        flow_mags_norm_2(:,k) = flow_mags_c(:,i)/3;
    else
        kk = round(frame_ids_r(2,i)/300000);
        for jj = 1:kk
            k = k+1;
            flow_mags_norm_2(:,k) = flow_mags_c(:,i)/kk;
        end
    end
end

num_frames = size(flow_mags_norm_2,2);
bin_size = 0.005;
num_bins = round(max(max(flow_mags_norm_2))/bin_size); 
flow_mags_hist_2 = zeros(num_bins+1,num_frames-1);
for i = 1:num_frames-1
    for j = 1:c_f_size
        k = num_bins-round(flow_mags_norm_2(j,i)/bin_size)+1;
        flow_mags_hist_2(k,i) = flow_mags_hist_2(k,i)+1;
    end
end
%%

mean_psd = pwelch(mean(flow_mags_hist_2,1),num_frames-1,[],[],30);
flow_psd = zeros(k,size(mean_psd,1));
for i = 1:k                                   
    flow_psd(i,1:size(mean_psd,1)) = pwelch(flow_mags_hist_2(i,:),num_frames-1,[],[],30);
end

disp(['Saving - subject: ' num2str(subj) ' experiment: ' exp_no])
save([data_dir '\OF_data_2_psd_subj' num2str(subj) '_exp_' exp_no '.mat'], 'flow_mags_norm', 'flow_mags_hist', 'frame_ids', 'flow_psd', '-v7.3');

% figure;                                                               
% pwelch(mean(flow_mags_hist4,1),355,[],[],30)


%%

% for subj = 1
%     for exp_no_ind = 64:73
        %exp_no = ['02' num2str(exp_no_ind) '002' num2str(subj+1)];
        %data_dir = ['G:\ASLR_May2019_Study\Kinect\Processed data\Subject' num2str(subj) '\' exp_no];
        %load([data_dir '\OF_data_psd_subj' num2str(subj) '_exp_' exp_no '.mat'], 'flow_mags_hist');
        figure(5);
        imagesc(20*log10(flow_psd))
        saveas(gcf, ['D:\repos\ASLR\Scripts\Figures\hist_n_psd2\mean_psd_subj' num2str(subj) '_exp_' exp_no '.fig'])
        saveas(gcf, ['D:\repos\ASLR\Scripts\Figures\hist_n_psd2\mean_psd_subj' num2str(subj) '_exp_' exp_no '.png'])
%     end
% end
% 
% for subj = 2
%     for exp_no_ind = 64:73
        %exp_no = ['02' num2str(exp_no_ind) '002' num2str(subj+1)];
        %data_dir = ['G:\ASLR_May2019_Study\Kinect\Processed data\Subject' num2str(subj) '\' exp_no];
        %load([data_dir '\OF_data_psd_subj' num2str(subj) '_exp_' exp_no '.mat'], 'flow_mags_hist');
        figure(6);
        %imagesc(flow_mags_hist);
        imagesc(20*log10(flow_mags_hist_2))
        caxis([0 40])
        saveas(gcf, ['D:\repos\ASLR\Scripts\Figures\hist_n_psd2\hist_subj' num2str(subj) '_exp_' exp_no '.fig'])
        saveas(gcf, ['D:\repos\ASLR\Scripts\Figures\hist_n_psd2\hist_subj' num2str(subj) '_exp_' exp_no '.png'])
%     end
% end

%%
% k = 1;
% full_frames(1,1) = 1;
% for i = 2:372
% k = k+round(frame_ids(2,i)/330000);
% full_frames(1,k) = 1;
% end

% full_frames(2,:) = (0:0.0333333333333333333333:752/30-0.033);
%%
xlabel('Time (s)');
ylabel('Optical Flow (px/frame)');

y_max = size(flow_mags_hist_2,1);
y_min = mod(y_max,500);
x_max = size(flow_mags_hist_2,2);

yticks_num = [y_min:500:y_max];
yticks(yticks_num);
ytl = {};
for i = 1:size(yticks_num,2)
    ytl{i} = num2str((size(yticks_num,2)-i)*2.5,'%.2f');
end
yticklabels(ytl);

xticks_num = [30:30:x_max];
xticks(xticks_num);
xtl = {};
for i = 1:size(xticks_num,2)
    xtl{i} = num2str(i);
end
xticklabels(xtl);

colormap(jet);