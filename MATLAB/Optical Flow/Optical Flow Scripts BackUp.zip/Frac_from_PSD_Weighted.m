function [betabar, betabarmean, magnitude_mean, start_bin] = Frac_from_PSD_Weighted(fIn,fps, weight)
        
        
load(fIn);

if exist('psdout1','var') == 1
        psdoutY = psdout1;
end
if exist('psdout2','var') == 1
        psdoutY = psdout2;
end
if exist('psdout3','var') == 1
        psdoutY = psdout3;
end
if exist('psdout','var') == 1
        psdoutY = psdout;
end

totalpx = sum(psdoutY(:)); % total # of pixels
rownum = 1;
for i = size(psdoutY,1):-1:1
        
        psdoutx(rownum,:) = psdoutY(i,:);
        
        if sum(psdoutx(:)) > totalpx*weight
                break
        end
        rownum = rownum+1;
end
%% linear log/log
% ln(M) = beta*ln(f)+alpha          y = a*x+b
size_j = size(psdoutx,1);
size_f = size(psdoutx,2);

start_bin = size(psdoutY,1)-size_j+1;

fits = cell(1,size_j);
sample = 1;
for j = 1:size_j
    if psdoutx(j,1) > 0
%         freq = log((2:size_f-1)/(size_f-1)*fps/2);
%         magnitude = log(psdout(j,2:size_f-1));
        freq = log((2:size_f-1)/(size_f-1)*fps/2);
        magnitude = log(psdoutx(j,2:size_f-1));
        x = sum(isinf(magnitude));
        if x == 0
                fits{sample} = fit(freq',magnitude','poly1');
                sample = sample+1;
        end
    end
end
%% Fractal Complexity     
betabar = 0;
k=0;
for i=1:size_j
    if ~isempty(fits{i})
        betabar = betabar + fits{i}.p1;
        k = k+1;
    end
end
betabar = - betabar;
betabarmean = betabar/k; % mean fractal complexity   
%% ALPHA
% alphabar = 0;
% j=0;
% for i=1:size_j
%     if ~isempty(fits{i})
%         alphabar = alphabar + exp(fits{i}.p2);
%         j = j+1;
%     end
% end
% alphabarmean = alphabar/j; % mean spectral density amplitude

%% Mean of Magnitude func

count = 0;
for i = 1:size_j
    if ~isempty(fits{i})
    magnitude_func(i,:) = exp(fits{i}.p2)./abs(exp(freq)).^(-fits{i}.p1);
    count = count+1;
    end
    
end
magnitude_mean = mean(magnitude_func);
end