clear; clc; close all; warning off;

DATA_DIR = '/media/rspl-admin/FantomHD/Daily Data/20 Jan 2020/77GHz/Front/';           % ** Adjust acc to your pattern**
OUT_DIR = '/mnt/HDD01/rspl-admin/ASL vs Daily Videos/RD OF and PSD/Final 77 Daily/';     % ** Adjust acc to your pattern**
% DATA_DIR = 'C:\Users\mrahman17\Desktop\Genetic Algorithm\Activity_Recognition_data\05_Walking_Towards_radar\';           % ** Adjust acc to your pattern**

pattern = strcat(DATA_DIR, '*.bin');    % file pattern
files = dir(pattern);

% w = waitbar(0);

I_MAX = numel(files); % # of files in "files" 
   
for i = 1:I_MAX   % for the first 20 iteration
    tic
    msg = strcat(['Processing file ', int2str(i), ' of ', int2str(I_MAX)]);   % loading message
%     waitbar(i/I_MAX, w, msg);
    disp(msg);
    fName = files(i).name;
    [foo1, name, foo2] = fileparts(fName);
    fIn = fullfile(files(i).folder, files(i).name);
    fOut = strcat(OUT_DIR, name, '.png');
    fOut_vid = strcat(OUT_DIR, name, '.avi');
%     datToImage_Anchortek_No_MTI(fIn, fOut, fName);
%     datToImageV1( fIn, fOut, fName )
%     datToImage_77( fIn, fOut, fName );
%     datToImage_matrix(fIn, fOut, fName );
%     datToImage_77_MTI( fIn, fOut, fName );
%     rangeDoppler_Anchortech(fIn, fOut_vid, fName);
%     debug_CVD(fIn, fOut, fName);
%     Xethru_spec(fIn, fOut, fName);
%     rangeDopp_Video(fIn, fOut_vid, fName);
%     range_Dopp_apart(fIn, fOut_vid, fName);
%     optical_flow_auto(fIn, fOut, fName);
%     PSD_auto(fIn, fOut, fName);
%     vel_est_77(fIn, fOut, fName);
%     opt_flow_velocity(fIn, fOut, fName);
    opticalFlow_77_20sec(fIn, fOut, fName);
toc
end

% close(w);
